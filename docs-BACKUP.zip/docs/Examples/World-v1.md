# World-v1

World-v1 is an example environment build with WOB, it was used to perform initial experiments in [this paper](https://arxiv.org/abs/2202.12884).

DETAILS COMING SOON

